import { Fragment } from 'react'

export const Graph: React.FC<{ company: string }> = () => {
	return <Fragment></Fragment>
}
