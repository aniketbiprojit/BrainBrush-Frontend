import { ApplicationActions } from './states/ApplicationState/ApplicationSlice'

export default {
	ApplicationActions: ApplicationActions,
}
