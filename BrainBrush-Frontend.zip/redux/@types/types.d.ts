declare namespace ReduxStateTypes {
	interface IApplicationState {
		loggedIn: boolean
	}
}
