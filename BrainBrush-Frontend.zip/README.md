# BrainBrush-Frontend

## Install Instructions

`yarn`

## Running Instructions

`yarn dev`
