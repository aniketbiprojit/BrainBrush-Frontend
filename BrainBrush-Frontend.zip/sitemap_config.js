module.exports = {
	siteUrl: 'https://brainbrush.aniketbiprojit.me',
	generateRobotsTxt: true,
}
